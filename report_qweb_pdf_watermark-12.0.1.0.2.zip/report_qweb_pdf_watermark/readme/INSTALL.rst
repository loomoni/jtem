
As PyPDF is not supported in python3, you need to install PyPDF2::

$ pip install pypdf2
