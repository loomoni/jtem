## Module <hr_zk_attendance>

#### 24.04.2019
#### Version 12.0.1.0.0
##### ADD
- Initial commit

#### 26.11.2019
#### Version 12.0.1.0.1
##### FIX
- Bug Fixed


#### 27.12.2019
#### Version 12.0.1.1.1
##### FIX
- Bug Fixed : timezone issue in cronjob
